

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class EvaluatorTests {

	@Before
	public void setUp() throws Exception {
		//Evaluator test = new Evaluator(); 
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
