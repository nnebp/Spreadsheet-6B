import java.awt.Component;
import java.text.ParseException;

import javax.swing.DefaultCellEditor;
import javax.swing.JFormattedTextField;
import javax.swing.JTable;
import javax.swing.JTextField;

public class CellEditor extends DefaultCellEditor{
	
	/**
	 * Generated UID. 
	 */
	private static final long serialVersionUID = -754912053220419892L;

	/** reference to editor component*/
	private JFormattedTextField myComponent;
	
	public CellEditor() {
		super(new JFormattedTextField());
		myComponent = (JFormattedTextField) getComponent();

		myComponent.setHorizontalAlignment(JTextField.TRAILING);
        myComponent.setFocusLostBehavior(JFormattedTextField.PERSIST);
	}

	// return the forumla for editing
    public Component getTableCellEditorComponent(JTable table,
            Object value, boolean isSelected,
            int row, int column) {

        myComponent = (JFormattedTextField)super.getTableCellEditorComponent(
                table, value, isSelected, row, column);
        
        myComponent.setValue(value);
        System.out.println("the class of value is :" + value.getClass());
        myComponent.setText(((Cell)value).formula);
        return myComponent;
    }
    //THIS IS WHAT IS SET IN THE CELL
    public Object getCellEditorValue() {
		//myComponent = (JFormattedTextField)getComponent();
		Cell temp = new Cell((String) myComponent.getValue());
    	return (temp);
    }
    
    
    public boolean stopCellEditing() {
		//myComponent = (JFormattedTextField)getComponent();
		
    	try {
			myComponent.commitEdit();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return super.stopCellEditing();
    }
}
