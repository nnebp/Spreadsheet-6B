public class Cell { 
	
	public String formula; 
	//public int value;
	
	Cell( /*int val, */String form) {
		super();
		//value = val;
		formula = form;
	}
	
	/**
	 *  Test method to add somethign to display. adds first
	 *  and last char in formula string.
	 * @return value of formula (test)
	 */
	public int getCellValue() {
		return	Character.getNumericValue(formula.charAt(0)) + 
		Character.getNumericValue(formula.charAt(formula.length() - 1)); 
	}
	
	public String toString() {
		if (formula.isEmpty()) {
			return "";
		}
		return new Integer(getCellValue()).toString();
	}
	
// the expression tree below represents the formula private ExpressionTree expressionTree;
	//public void Evaluate (Spreadsheet spreadsheet); }
}