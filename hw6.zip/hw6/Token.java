
/**
 * Abstract class Token - write a description of the class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Token
{
    // instance variables - replace the example below with your own
    private int x;


}
